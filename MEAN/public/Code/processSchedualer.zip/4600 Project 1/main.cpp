#include "Generator.h"
#include "Schedular.h"
using namespace std;
int main()
{
	Generator start;
	srand(time(NULL));//seed time
    Schedular run;
	int choice=0;
	int print=-1;
	int pid=1000;
	int cycl,Mem,times;
	vector<node> s (101);
	cout<<"Welcome to the process schedular."<<endl;

	while(choice!=5)
	{
	cout<<"1. To run the process schedular for 5 identical CPU's."<<endl;
	cout<<"2. To run the process schedular for varying memory sizes and same clock speed CPU's."<<endl;
	cout<<"3. To run the process schedular for varying clock speed and same memory size CPU's."<<endl;
	cout<<"4. To run the process schedular for varying arrival time over identical CPU's"<<endl;
	cout<<"5. To quit."<<endl;
	cin>>choice;
	
	if(choice==1)//Run identical process schedular 
	{
	cout<<"home many times would you like to run the experiment?"<<endl;
	cin>>times;
    while(print!=1||print!=0)
	 {
	cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	cin>>print;
	if(print==1||print==0){break;}
	 }

	for(int i=1;i<=times;i++)
	{
	cout<<"Run: "<<i<<endl;
	start.Gen(s);
	run.indentical(s,i,print);

	}
	}

	else if(choice==2)//run test on varying memory sizes
	{
   cout<<"home many times would you like to run the experiment?"<<endl;
	cin>>times;
	 while(print!=1||print!=0)
	 {
	cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	cin>>print;
		if(print==1||print==0){break;}
	 }
	for(int i=1;i<=times;i++)
	{
	cout<<"Run: "<<i<<endl;    
	start.Gen(s);
	run.memory_base(s,i,print);
	
	}
	}

	else if(choice==3)//run test on process schedular for varying clock speeds. 
    {
     cout<<"home many times would you like to run the experiment?"<<endl;
	 cin>>times;
	  while(print!=1||print!=0)
	 {
	 cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	 cin>>print;
	 	if(print==1||print==0){break;}
	 }
	 for(int i=1;i<=times;i++)
	 {
	 cout<<"Run: "<<i<<endl;
	 start.Gen(s); 
	 run.cycle_base(s,i,print);
	 }
	 }

	else if(choice==4)//run test on process schedular varying arrival times. 
    {
     cout<<"home many times would you like to run the experiment?"<<endl;
	 cin>>times;
     while(print!=1||print!=0)
	 {
	 cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	 cin>>print;
	 	if(print==1||print==0){break;}
	 }
	 for(int i=1;i<=times;i++)
	 {
	 cout<<"Run: "<<i<<endl;    
	 start.Gen(s);
	 run.real_time(s,i,print);
	 }
     }

	else if(choice==5)//print all process
        {
	        cout<<"exiting program...."<<endl<<endl;
        }

	else
	{
	cout<<"Oh no that command is not recognized. Please try again."<<endl;
	}

	}

	return 0;
}