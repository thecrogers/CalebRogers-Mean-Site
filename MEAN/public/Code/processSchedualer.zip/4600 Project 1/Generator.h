#ifndef GENERATORHEADERFILE
#include<iostream>
#include <stdlib.h> 
#include <vector>
#include <time.h>
#include "node.h"
#define GENERATORHEADERFILE

class Generator
{
 public:
 Generator(){};
 void Gen(std::vector<node>&);
 int pGen();  

private:

};
#endif