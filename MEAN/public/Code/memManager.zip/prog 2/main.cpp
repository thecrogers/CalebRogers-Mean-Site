#include "Generator.h"
#include "Memory_manager.h"
using namespace std;
int main()
{
	Generator start;
	memManger my;
	srand(time(NULL));//seed time
   
	int choice=0;
	int print=-1;
	int pid=1000;
	int limit=0;
	int cycl,Mem,times;
	vector<node> s (50);
	cout<<"Welcome to the process schedular."<<endl;

	while(choice!=4)
	{
	cout<<"1. To run the processes with malloc and free"<<endl;
	cout<<"2. To run the processes with my_malloc and my_free"<<endl;
	cout<<"3. To run the processes with limited memory"<<endl;
	cout<<"4. To quit."<<endl;
	cin>>choice;
	
	if(choice==1)//Run System Malloc and Free
	{
	cout<<"home many times would you like to run the experiment?"<<endl;
	cin>>times;
    while(print!=1||print!=0)
	 {
	cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	cin>>print;
	if(print==1||print==0){break;}
	 }

	for(int i=1;i<=times;i++)
	{
	for(int j=0;j<50;j++){
	s[j].ID = 0;
	s[j].cycle = 0;
	s[j].mallocSpeed = 0;
	s[j].remaining = 0;
	s[j].freeSpeed = 0;
	s[j].mem = 0;
	s[j].state = 0;
	}
	cout<<"Run: "<<i<<endl;
	start.Gen(s);
    my.systemAlloc(s,i,print);
	s.clear();
	s.resize(50);
	}
	}

	else if(choice==2)//run test on varying memory sizes
	{
   cout<<"home many times would you like to run the experiment?"<<endl;
	cin>>times;
	 while(print!=1||print!=0)
	 {
	cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	cin>>print;
		if(print==1||print==0){break;}
	 }
	for(int i=1;i<=times;i++)
	{
	 for(int j=0;j<50;j++){
	s[j].ID = 0;
	s[j].cycle = 0;
	s[j].mallocSpeed = 0;
	s[j].remaining = 0;
	s[j].freeSpeed = 0;
	s[j].mem = 0;
	s[j].state = 0;
	}
	cout<<"Run: "<<i<<endl;    
	start.Gen(s);
	my.myAlloc(s,i,print);
	s.clear();
	s.resize(50);
	}
	}

	else if(choice==3)//run test on process schedular for varying clock speeds. 
    {
     cout<<"home many times would you like to run the experiment?"<<endl;
	 cin>>times;
	 cout<<"what would you like the memory limit to be?"<<endl;
	 cin>>limit;

	  while(print!=1||print!=0)
	 {
	 cout<<"would you like to print processor lists? (1 for yes or 0 for no)"<<endl;
	 cin>>print;
	 	if(print==1||print==0){break;}
	 }
	 for(int i=1;i<=times;i++)
	 {
	for(int j=0;j<50;j++){
	s[j].ID = 0;
	s[j].cycle = 0;
	s[j].mallocSpeed = 0;
	s[j].remaining = 0;
	s[j].freeSpeed = 0;
	s[j].mem = 0;
	s[j].state = 0;
	}
	 cout<<"Run: "<<i<<endl;
	 start.Gen(s);
	 my.limited(s,i,print,limit);
	 s.clear();
	 s.resize(50);
	 }
	 }
	else if(choice==4)//print all process
        {
	        cout<<"exiting program...."<<endl<<endl;
        }

	else
	{
	cout<<"Oh no that command is not recognized. Please try again."<<endl;
	}

	}

	return 0;
}
